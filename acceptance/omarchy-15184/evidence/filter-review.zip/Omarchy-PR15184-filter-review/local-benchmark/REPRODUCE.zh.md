# 本地编码基准复现

这是编码微基准，不是桌面验收；不调用模型，也不连接Wayland。输入为上一轮干净VM的原始真实截图。依赖C编译器、Wayland/libpng开发包、wayland-scanner及Python Pillow。

在本目录执行：

```sh
sh build.sh /tmp/native-review-build
cc -std=c11 -O2 -Wall -Wextra -Werror -I/tmp/native-review-build $(pkg-config --cflags wayland-client libpng) verify-every-encoding.c /tmp/native-review-build/screencopy-protocol.c $(pkg-config --libs wayland-client libpng) -o /tmp/native-review-build/benchmark
python3 - <<'PY'
from PIL import Image
for name in ['terminal','configtool']:
    Image.open(name+'-input.png').convert('RGBA').save('/tmp/'+name+'-rgba.png')
    open('/tmp/'+name+'.bgra','wb').write(Image.open(name+'-input.png').convert('RGBA').tobytes('raw','BGRA'))
PY
/tmp/native-review-build/benchmark /tmp/terminal.bgra 1280 800 5120 1 /tmp/terminal-adaptive.png
/tmp/native-review-build/benchmark /tmp/terminal.bgra 1280 800 5120 0 /tmp/terminal-none.png
/tmp/native-review-build/benchmark /tmp/configtool.bgra 1280 800 5120 1 /tmp/configtool-adaptive.png
/tmp/native-review-build/benchmark /tmp/configtool.bgra 1280 800 5120 0 /tmp/configtool-none.png
```

每次先预热5次，再输出100行编码纳秒、PNG字节数。所有105次PNG均在计时结束后解码，逐个RGB像素与输入比较；不相同会退出失败。不同CPU负载会改变耗时，不能预期复现相同数字。实际采集器源码固定bda9733b，基准直接包含其encode_png函数；运行结果见every-encoding-verified.json。
