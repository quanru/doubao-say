"""Plot all real source-event intervals; never filter by outcome."""
from pathlib import Path
import json,sys,math
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
r=Path(sys.argv[1]);rows=json.loads((r/'latency-results.json').read_text());assert len(rows)==40 and all(x.get('metrics') for x in rows)
fig,axes=plt.subplots(1,2,figsize=(13,9),sharex=True,layout='constrained');colors={'PASS':'#227447','FAIL':'#bb2929','INCONCLUSIVE':'#b57409'}
xmax=max(600,math.ceil(max(x['metrics']['full_keypress']['upper_ms'] for x in rows)/50)*50+25)
for ax,prefix,title in zip(axes,['switch','quick'],['Requested hold: 80 ms','Requested hold: 5 ms']):
 selected=[x for x in rows if x['trial'].startswith(prefix)];assert len(selected)==20
 for y,x in enumerate(selected):
  m=x['metrics']['full_keypress'];c=colors[m['status']];ax.plot([m['lower_ms'],m['upper_ms']],[y,y],color=c,linewidth=3,marker='|',markersize=9)
 ax.set_yticks(range(20),[x['trial']+'  '+x['metrics']['full_keypress']['status'][0] for x in selected]);ax.invert_yaxis();ax.set_xlim(0,xmax);ax.axvline(500,color='#353535',linestyle='--',linewidth=1.2);ax.grid(axis='x',alpha=.2);ax.set_title(title);ax.set_xlabel('Latency bounds (ms)');ax.spines[['top','right']].set_visible(False)
fig.suptitle('All 40 planned trials: full-keypress latency intervals\nGuest compositor source-event endpoint; dashed threshold = 500 ms',fontsize=13)
fig.legend(handles=[Line2D([0],[0],color=c,lw=3,label=s) for s,c in colors.items()],loc='outside lower center',ncol=3,frameon=False)
fig.savefig(r/'latency-intervals.png',dpi=160);plt.close(fig)
print(r/'latency-intervals.png')
