"""Audit raw guest trace and numeric allowance; never infer physical display accuracy."""
from pathlib import Path
from decimal import Decimal as D
import json,sys,statistics
r=Path(sys.argv[1]).resolve()
def read(p):return json.loads(p.read_text(),parse_float=D)
trace={}
for line in (r/'guest/native-capture-errors.log').read_text().splitlines():
 if not line.startswith('{'):continue
 x=json.loads(line);key=x['frameId']
 if key in trace:
  assert all(trace[key].get(k,v)==v for k,v in x.items()),'Conflicting trace identity'
  trace[key].update(x)
 else:trace[key]=x
clock=read(r/'versions/guest-clock-check.json');assert clock['allSteadySamplesBracketed'] and len(clock['samples'])==10000
samples=[list(map(int,x)) for x in clock['samples']];assert all(a<=s<=b for a,s,b in samples)
clock_summary={'samples':len(samples),'all_bracketed':True,'nominal_resolution_ns':clock['monotonicResolutionNs'],'largest_bracket_ns':max(b-a for a,s,b in samples),'observed_offset_intersection_ns':[max(s-b for a,s,b in samples),min(s-a for a,s,b in samples)],'limit':'Observed bracket intersection only, not an accuracy certificate. Same CLOCK_MONOTONIC backend is verified separately from compositor/runtime source.'}
assert clock_summary['observed_offset_intersection_ns'][0]<=0<=clock_summary['observed_offset_intersection_ns'][1]
rows=[];rounding=[];encode=[];output=[];copy=[];missing_emit=0
for trial in read(r/'latency-results.json'):
 name=trial['trial'];rec=read(r/'observations'/name/'observation.json');assert rec['captureMode']=='source' and rec['droppedFrames']==0
 for f in rec['frames']:
  t=trace[f['frameId']];assert t['adaptiveFilter'] is False
  req,src,ready,enc=[int(t[k]) for k in ['requestedNs','sourceNs','readyNs','encodedNs']]
  assert req<=src<=ready<=enc
  if 'emittedNs' in t:assert enc<=int(t['emittedNs']);output.append((int(t['emittedNs'])-enc)/1e6)
  else:missing_emit+=1
  assert (r/'observations'/name/f['path']).stat().st_size==t['pngBytes']
  lo,hi=[D(f['timing'][k])*1000000 for k in ['startMs','endMs']]
  assert lo<=src<=hi and hi-lo==2000,'Invalid numeric timestamp band'
  rounding.append(abs((lo+hi)/2-src));encode.append((enc-ready)/1e6);copy.append((ready-src)/1e6)
 old=trace[trial['old_frame']['frameId']];new=trace[trial['new_frame']['frameId']]
 events={e['name']:e['timing'] for e in rec['events']};down,up=events['keydown'],events['keyup']
 envelopes={}
 for metric,start,end in [('full_keypress',down['startMs'],up['endMs']),('keydown',down['startMs'],down['endMs']),('keyup',up['startMs'],up['endMs'])]:
  lo=max(D(0),D(old['requestedNs'])/1000000-D('.001')-end);hi=D(new['readyNs'])/1000000+D('.001')-start
  status='PASS' if hi<=500 else 'FAIL' if lo>500 else 'INCONCLUSIVE'
  envelopes[metric]={'lower_ms':str(lo),'upper_ms':str(hi),'status':status}
 rows.append({'trial':name,'boundary_frame_gap_ms':str(D(int(new['sourceNs'])-int(old['sourceNs']))/1000000),'source_event_metrics':trial['metrics'],'request_ready_envelope':envelopes})
def stats(x):return {'n':len(x),'min':min(x),'median':statistics.median(x),'max':max(x)}
result={'clock':clock_summary,'verified_exported_frames':len(rounding),'max_numeric_center_error_ns':str(max(rounding)),'numeric_band_width_ns':2000,'emitted_trace_missing':missing_emit,'encode_ms':stats(encode),'source_event_to_ready_ms':stats(copy),'encode_to_output_ms':stats(output),'rows':rows,'endpoint':'Hyprland RESULT_TIMESTAMP callback associated with the captured compositor mirror texture. Numeric ±1us is not sampling, copy, scheduler or physical presentation uncertainty. Request-to-ready envelope is separately reported as conservative acquisition sensitivity; it does not replace historical classifications.'}
(r/'capture-trace-verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2,default=str));print(json.dumps({k:v for k,v in result.items() if k!='rows'},ensure_ascii=False,indent=2,default=str))
