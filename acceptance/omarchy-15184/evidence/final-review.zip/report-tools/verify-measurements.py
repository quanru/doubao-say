"""Validate real capture integrity and stable transitions; do not relax CI criteria."""
from pathlib import Path
from PIL import Image
import json,hashlib,sys
r=Path(sys.argv[1]);g=r/'guest'
def pix(p):
 with Image.open(p) as im:
  if im.size==(1280,28):
   x,y,w,h=json.loads((r/'roi.json').read_text())['box'];im=im.crop((x,y,x+w,y+h))
  return hashlib.sha256(im.convert('RGB').tobytes()).hexdigest()
results=[]
if (g/'active.png').exists() and (g/'inactive.png').exists():
 active=pix(g/'active.png');inactive=pix(g/'inactive.png')
 for d in sorted(g.glob('switch*')):
  p=d/'capture.json'
  if not p.exists():continue
  c=json.loads(p.read_text());frames=c['frames'];i=int(d.name.removeprefix('switch'))
  target,old=(active,inactive) if i%2==0 else (inactive,active)
  classes=[pix(d/f['file']) for f in frames];new=next((n for n,h in enumerate(classes) if h==target),None)
  bad_hash=[f['file'] for f in frames if hashlib.sha256((d/f['file']).read_bytes()).hexdigest()!=f['sha256']]
  ordered=all(a['lo_ns']<=a['hi_ns']<=b['lo_ns'] for a,b in zip(frames,frames[1:]))
  post=classes[new:] if new is not None else []
  ups=[e['ns'] for e in c['events'] if e['value']==0];downs=[e['ns'] for e in c['events'] if e['value']==1]
  item={'trial':d.name,'frame_count':len(frames),'file_hash_mismatches':bad_hash,'frame_brackets_ordered':ordered,'target_seen':new is not None,'old_state_after_first_target':sum(h==old for h in post),'unknown_pixels_after_first_target':sum(h not in [active,inactive] for h in post),'supplemental_only_does_not_replace_primary_interval':True}
  if new is not None and len(ups)==len(downs)==1:
   item['key_down_to_target_upper_ms']=(frames[new]['hi_ns']-(downs[0]-1000))/1e6
   item['key_up_to_target_upper_ms']=(frames[new]['hi_ns']-(ups[0]-1000))/1e6
  results.append(item)
(r/'measurement-integrity-review.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps({'trials':len(results),'integrity_failures':sum(bool(x['file_hash_mismatches']) or not x['frame_brackets_ordered'] for x in results),'unstable_transitions':sum(x['old_state_after_first_target']>0 or x['unknown_pixels_after_first_target']>0 for x in results)},indent=2))
