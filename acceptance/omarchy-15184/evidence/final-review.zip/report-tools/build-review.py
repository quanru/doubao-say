"""Create a Chinese review report from actual exported evidence only."""
from pathlib import Path
import json,html,sys,hashlib,base64
r=Path(sys.argv[1]).resolve()
def read(name,fallback=None):
 p=r/name
 return json.loads(p.read_text()) if p.exists() else fallback
ui=read('ui-results.json',[]);lat=read('latency-results.json',[])
pins=read('versions/source-pins.json',{});versions=read('guest/package-versions.json',{})
rows=[x for x in lat if x.get('trial')];counts={s:sum(x.get('status')==s for x in rows) for s in ['PASS','FAIL','INCONCLUSIVE']}
case1='未执行' if not rows else '失败' if counts['FAIL'] else '待审阅/计时不确定' if counts['INCONCLUSIVE'] or len(rows)!=20 else '自动测量通过，待像素证据审阅'
config=[x for x in ui if str(x.get('trial','')).startswith('config-round-')]
case2=('自动检查通过，待截图审阅' if all(x.get('status')=='GUI_LIST_AND_VISUAL_CHECK_PASSED' for x in config) else '3轮列表操作完成；视觉断言有失败，须独立复核') if len(config)==3 else '未完成：见失败记录'
restore=read('guest/restore.json',{})
packages='\n'.join(x for x in versions.get('packages','').splitlines() if x.startswith(('hyprland ','fcitx5','quickshell ','omarchy-')))
steps=['用真实 QEMU/QMP 虚拟键盘激活 Pinyin，并输入 nihao，检查实际提交的汉字。','在同一应用中使用已配置的左 Shift 切换，重复20次；读取 guest evdev 的单调时钟时间戳，同步保存顶栏原始像素（最新轮次保留完整顶栏帧，分析时使用记录的ROI）。','通过真实 fcitx5-configtool GUI 删除 Pinyin 并 Apply，再添加 Pinyin 并 Apply，重复3轮；每次观察5秒，检查列表与顶栏，并核对 shell/fcitx/indicator PID及启动时间。','先在 GUI 恢复原输入法列表；验收完成后才重启测试 VM 内的 fcitx5，恢复配置备份并核对字节。']
def esc(x):return html.escape(str(x))
def timing_evidence(x):
 trial=x.get('trial');old=x.get('old_frame');new=x.get('new_frame')
 if not trial:return esc(x.get('reason',''))
 links=[f'<a href="guest/{esc(trial)}/capture.json">事件及时间区间</a>']
 for label,name in [('最后旧状态',old),('最初新状态',new)]:
  if name:links.append(f'<a href="guest/{esc(trial)}/{esc(name)}">{label}</a>')
 return ' · '.join(links)

body=f'''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>Omarchy PR #15184 真实验收审阅报告</title><style>body{{max-width:1100px;margin:40px auto;padding:0 24px;font:16px/1.7 system-ui;color:#18242e}}h1{{font-size:30px}}h2{{margin-top:36px}}table{{border-collapse:collapse;width:100%}}td,th{{border:1px solid #ccd5dc;padding:8px;text-align:left}}pre{{white-space:pre-wrap;background:#f1f4f6;padding:16px;overflow-wrap:anywhere}}img{{max-width:100%;border:1px solid #cbd5dc}}.note{{background:#fff1d7;padding:15px}}a{{color:#165dab}}</style><h1>Omarchy PR #15184 · 真实桌面验收</h1><p class="note">供用户审阅。自动结果必须结合原始截图；缺失证据或未执行项不能标记为通过。未向上游发布、评论或合并。</p><table><tr><th>验收项</th><th>当前证据结论</th></tr><tr><td>应用内切换后500ms内更新</td><td>{esc(case1)}</td></tr><tr><td>配置工具改列表后无重启刷新</td><td>{esc(case2)}</td></tr></table><h2>环境与固定版本</h2><p>公开仓库标准 GitHub-hosted Ubuntu runner；真实 QEMU/KVM guest、Hyprland 与 fcitx5；Midscene 通过 VNC 驱动和观察 guest。非网页模拟界面。</p><pre>{esc(json.dumps(pins,ensure_ascii=False,indent=2))}\n内核：{esc(versions.get('kernel','未取得'))}\n{esc(packages)}</pre><p>安装文件校验：{esc(read('guest/candidate-integrity.json','未取得'))}</p><p>版本辨识说明：local-source 构建保留打包配方的 pkgver（可能显示 gf5006bd），其 OMARCHY_SRC 路径实际复制本次固定候选源码。因此以 source-pins.json、ISO SHA-256 和安装后逐文件哈希校验共同辨识测试对象，不能只拿软件包版本字符串当 PR commit。</p><h2>操作与实际结果</h2><ol>{''.join('<li>'+esc(s)+'</li>' for s in steps)}</ol><pre>{esc(json.dumps(ui,ensure_ascii=False,indent=2))}</pre><h2>计时方法与逐次结果</h2><p>输入来源是QMP真实虚拟键盘，时间来自guest evdev CLOCK_MONOTONIC。每张grim截图记录开始和结束时间；用稳定状态模板核对原始像素。主结果从按下至松开的输入区间推导保守上下界：上界≤500ms才通过，下界&gt;500ms才失败，其余不确定。未测量物理显示器扫描/光子延迟；模型响应和VNC传输耗时不用于500ms结论。</p><table><tr><th>样本</th><th>结果</th><th>下界 ms</th><th>上界 ms</th><th>原始证据</th></tr>{''.join('<tr>'+''.join('<td>'+esc(x.get(k,''))+'</td>' for k in ['trial','status','lower_ms','upper_ms'])+'<td>'+timing_evidence(x)+'</td></tr>' for x in lat)}</table><h2>恢复与费用证据</h2><pre>{esc(json.dumps(restore,ensure_ascii=False,indent=2))}</pre><p>参阅原始 model-money-ledger.jsonl（存在时）及 budget-policy.json；预留额度不等于最终实付。失败/缺失usage的请求保留最坏费用。累计模型预算100元，不充值。</p><h2>真实截图</h2>'''
for p in sorted((r/'guest').glob('*.png')):
 body+=f'<figure><figcaption>{esc(p.name)}</figcaption><a href="guest/{esc(p.name)}"><img src="data:image/png;base64,{base64.b64encode(p.read_bytes()).decode()}"></a></figure>'
body+='<h2>原始 Midscene 报告</h2><ul>'
for p in sorted((r/'midscene').rglob('*.html')):body+=f'<li><a href="{esc(p.relative_to(r))}">{esc(p.name)}</a></li>'
body+='</ul><p>原始截图、逐帧capture.json、latency.csv与文件校验表随本目录保存。</p></html>'
(r/'REVIEW.zh.html').write_text(body)
(r/'REVIEW.zh.md').write_text(f'''# Omarchy PR #15184 真实验收审阅报告

- 应用内切换：{case1}；{counts}，已取得{len(rows)}/20个计时样本。
- GUI列表修改：{case2}；已取得{len(config)}/3轮结果。
- PR head：{pins.get('omarchy','未取得')}。
- 配置恢复：{restore}。

详细环境、步骤、实际结果、计时方法及截图见同目录 REVIEW.zh.html。原始 Midscene HTML 在 midscene/。本报告不以静态代码检查或合成图片代替真实验收。
''')
(r/'SHA256SUMS').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+str(p.relative_to(r))+'\n' for p in sorted(r.rglob('*')) if p.is_file() and p.name!='SHA256SUMS'))
print(r/'REVIEW.zh.html')
