"""Summarize bounded request accounting; never claim provider invoice cost."""
from pathlib import Path
import json,sys
reports=[]
for arg in sys.argv[1:]:
 r=Path(arg);p=r/'model-money-ledger.jsonl'
 if not p.exists():
  reports.append({'run_directory':r.name,'accounting':'MISSING'});continue
 state={};events={}
 for line in p.read_text().splitlines():
  x=json.loads(line);state[x['id']]=x['micro_cny'];events[x['id']]=x['event']
 requests=[];q=r/'model-request-count.jsonl'
 if q.exists():requests=[json.loads(x) for x in q.read_text().splitlines() if x]
 reports.append({'run_directory':r.name,'reserved_request_count':len(state),'settled_requests':sum(v=='settle' for v in events.values()),'unsettled_worst_case_requests':sum(v!='settle' for v in events.values()),'conservative_accounted_micro_cny':sum(state.values()),'upstream_statuses':[x.get('status') for x in requests],'prompt_tokens':sum((x.get('usage') or {}).get('prompt_tokens',0) for x in requests),'completion_tokens':sum((x.get('usage') or {}).get('completion_tokens',0) for x in requests)})
print(json.dumps({'currency':'CNY','invoice_verified':False,'method':'Last reserve/settle value per request ID; unsettled reservations retained at worst case. Official-price ceiling accounting, not paid invoice.','runs':reports,'total_conservative_micro_cny':sum(x.get('conservative_accounted_micro_cny',0) for x in reports),'missing_ledgers':sum(x.get('accounting')=='MISSING' for x in reports)},ensure_ascii=False,indent=2))
