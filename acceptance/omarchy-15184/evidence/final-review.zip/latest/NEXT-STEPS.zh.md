# 尚未执行的补测方案

1. 保留本轮13通过/7不确定的主结果，不改变已记录的判定口径。下一版采集应减少帧时间区间宽度，例如记录Wayland screencopy精确ready时间；先对时间基准、帧语义与误差界验证，再独立复测。不要以模型视觉、平均数或更改按键起算点追认本轮通过。
2. GUI每轮显式aiTap「Input Method」页签；aiTap左侧当前Pinyin；aiTap右箭头；aiTap Apply；观察列表/进程及顶栏。用aiBoolean判断Only Show Current Language是否勾选，仅勾选时aiTap取消；aiTap搜索框，QMP Ctrl+A再逐键输入pinyin；aiTap右侧精确Pinyin，aiTap左箭头，aiTap Apply；每次保留截图、列表精确ID和PID/start_ticks。重复3轮，最后核对初始列表。
3. 复用临时分支已保存的完整可执行CI与锁定依赖，但新执行必须分配新run ID，继续累计100元总预算；重跑同一run attempt会被预算门禁拒绝。仅在可丢弃的公开标准runner/VM内运行，不在日用桌面执行。
4. 当前报告先供审阅；上述改进没有作为已执行结果报告。源脚本和原始失败证据随包保留，未创建未来自动运行。
