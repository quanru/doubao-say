"""Independent offline verification of complete native evidence, using decimal clock bounds."""
from pathlib import Path
from decimal import Decimal as D
from functools import lru_cache
from PIL import Image
import json,hashlib,sys,collections
r=Path(sys.argv[1]).resolve()
def read(p):return json.loads(p.read_text(),parse_float=D)
issues=[];rows=[];manifest_count=0
for line in (r/'SHA256SUMS').read_text().splitlines():
 digest,name=line.split('  ',1);p=(r/name).resolve();assert p.is_relative_to(r),name
 assert p.is_file() and hashlib.sha256(p.read_bytes()).hexdigest()==digest,name
 manifest_count+=1
integrity=read(r/'guest/candidate-integrity.json');assert not integrity['mismatches']
try:
 lifecycle=read(r/'versions/native-lifecycle.json');assert len(lifecycle)==3 and all(x['remainingCapturePids']==[] for x in lifecycle)
except (OSError,AssertionError) as e:issues.append('Native lifecycle preflight absent or invalid: '+str(e))
# Compare process identity independently of the UI driver's own assertions.
process_snapshots=0
try:
 initial=read(r/'guest/ui-initial.json')
 identity=lambda x:sorted((p['pid'],p['start_ticks'],p['comm']) for p in x['processes'])
 baseline=identity(initial)
 assert len(baseline)==3 and {x[2] for x in baseline}=={'quickshell','fcitx5','python3'}
 for p in sorted((r/'guest').glob('observation-*.json')):
  assert identity(read(p))==baseline, 'Process changed in '+p.name
  process_snapshots+=1
 assert process_snapshots>=42, 'Missing repeated switching snapshots'
except (OSError,AssertionError,KeyError) as e:issues.append('Process continuity: '+str(e))
roi=read(r/'roi.json')['box']
@lru_cache(None)
def pixels(p,full=False):
 with Image.open(p) as im:
  if full:
   assert im.size==(1280,800)
   x,y,w,h=roi;im=im.crop((x,y,x+w,y+h))
  return hashlib.sha256(im.convert('RGB').tobytes()).hexdigest()
active=pixels(r/'guest/active.png');inactive=pixels(r/'guest/inactive.png');assert active!=inactive
saved={x['trial']:x for x in read(r/'latency-results.json') if x.get('trial')}
for prefix in ['switch','quick']:
 for i in range(20):
  trial=f'{prefix}{i:02}';directory=r/'observations'/trial
  try:
   rec=read(directory/'observation.json');assert rec['captureMode']=='source' and rec['droppedFrames']==0
   assert read(directory/'cleanup.json')['remainingCapturePids']==[], 'Producer survived stop'
   events=read(r/'guest'/trial/'input.json');raw_down=[e for e in events['events'] if e['value']==1];raw_up=[e for e in events['events'] if e['value']==0]
   assert len(raw_down)==len(raw_up)==1
   down=[e['timing'] for e in rec['events'] if e['name']=='keydown'];up=[e['timing'] for e in rec['events'] if e['name']=='keyup'];assert len(down)==len(up)==1
   assert down[0]['endMs']<up[0]['startMs'] and events['clockId'].startswith('linux-monotonic:')
   for t,raw in [(down[0],raw_down[0]),(up[0],raw_up[0])]:
    assert t['clockId']==events['clockId'] and t['kind']=='input-event'
    assert abs(D(t['startMs'])-D(raw['ns']-1000)/1000000)<D('0.0000001')
    assert abs(D(t['endMs'])-D(raw['ns']+1000)/1000000)<D('0.0000001')
   frames=rec['frames'];assert len(frames)>=3
   identities=[f['frameId'].rsplit('-',1) for f in frames];assert len({x[0] for x in identities})==1
   numbers=[int(x[1]) for x in identities];assert numbers==list(range(numbers[0],numbers[0]+len(numbers))), 'Source frame sequence gap'
   previous=D('-1');states=[]
   old,new=(inactive,active) if i%2==0 else (active,inactive)
   for f in frames:
    t=f['timing'];assert t['clockId']==events['clockId'] and t['kind']=='compositor-frame'
    assert previous<=t['startMs']<=t['endMs'];previous=t['startMs']
    p=(directory/f['path']).resolve();assert p.is_relative_to(directory)
    assert hashlib.sha256(p.read_bytes()).hexdigest()==p.stem
    h=pixels(p,True);assert h in [old,new], 'Unknown ROI pixels';states.append(h)
   first=states.index(new);assert first>0 and all(h==old for h in states[:first]) and all(h==new for h in states[first:])
   assert any(f['timing']['endMs']<down[0]['startMs'] for f in frames[:first]),'Missing pre-input baseline'
   oldtime=frames[first-1]['timing']['startMs'];newtime=frames[first]['timing']['endMs'];computed={}
   for metric,start,end in [('full_keypress',down[0]['startMs'],up[0]['endMs']),('keydown',down[0]['startMs'],down[0]['endMs']),('keyup',up[0]['startMs'],up[0]['endMs'])]:
    lo=max(D(0),D(oldtime)-D(end));hi=D(newtime)-D(start)
    status='PASS' if 0<=hi<=500 else 'FAIL' if lo>500 else 'INCONCLUSIVE'
    existing=saved[trial]['metrics'][metric]
    assert abs(D(existing['lower_ms'])-lo)<D('0.000001') and abs(D(existing['upper_ms'])-hi)<D('0.000001')
    assert existing['status']==status, 'Numerical boundary classification differs'
    computed[metric]={'lower_ms':str(lo),'upper_ms':str(hi),'status':status}
   rows.append({'trial':trial,'frames':len(frames),'metrics':computed})
  except (OSError,ValueError,KeyError,AssertionError) as e:issues.append(trial+': '+str(e))
result={'manifest_files_verified':manifest_count,'candidate_files_verified':integrity['checked_files'],'process_snapshots_verified':process_snapshots,'verified_trials':len(rows),'verified_frames':sum(x['frames'] for x in rows),'issues':issues,'method':'Independent decimal arithmetic, original evdev events, PNG content hashes, contiguous frame identities, full ROI pixels and producer cleanup','results':rows}
(r/'independent-native-verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
print(json.dumps({k:v for k,v in result.items() if k!='results'},ensure_ascii=False,indent=2))
if issues or len(rows)!=40:sys.exit(1)
